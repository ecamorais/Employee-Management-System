/**
 *
 ** DatabaseConnection class handles the connection to a MySQL database
 */
import java.sql.*;
import javax.swing.JOptionPane;

public class DatabaseConnection {
    // JDBC driver name and database URL
 final static String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";              // MySQL JDBC driver class
  static final String DB_URL = "jdbc:mysql://localhost:3306/employee?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";

    // Database credentials
    final static String USER = "root";
 final static String PASS = "enricamorais3172003#@";


    /**
     * Establishes a connection to the database
     * @return Connection object if successful, null if failed
     */
    public static Connection connection(){
        try
        {
            Class.forName(JDBC_DRIVER);                             // Register JDBC driver
            Connection conn = DriverManager.getConnection(DB_URL,USER,PASS);    // Open a connection using the database URL and credentials
            return conn;
            
        }catch(Exception e){
            e.printStackTrace(); // Show full error in terminal         // Print full error stack trace to console
            JOptionPane.showMessageDialog(null, e);       // Show error message in a dialog box

            return null;
        }
     
        
        
    }
}
