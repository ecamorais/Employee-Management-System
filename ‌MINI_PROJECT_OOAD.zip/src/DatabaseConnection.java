/**
 *
 ** @author Priya Mohata
 */
import java.sql.*;
import javax.swing.JOptionPane;

public class DatabaseConnection {
    
 final static String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
  static final String DB_URL = "jdbc:mysql://localhost:3306/employee?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";


    final static String USER = "root";
 final static String PASS = "dbadmin";
    
 
    
    public static Connection connection(){
        try
        {
            Class.forName(JDBC_DRIVER); 
            Connection conn = DriverManager.getConnection(DB_URL,USER,PASS);
            return conn;
            
        }catch(Exception e){
            e.printStackTrace(); // Show full error in terminal
            JOptionPane.showMessageDialog(null, e);

            return null;
        }
     
        
        
    }
}
